module.exports = {
    todoController: require('./todos'),
    userController : require('./user')
}